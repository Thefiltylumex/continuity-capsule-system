THEFILTYLUMEX — CONTINUITY CAPSULE SYSTEM (CCS)
UNIFIED ROOT PACKAGE v1.0  (PUBLIC + PRIVATE in one drop)

This ZIP is a single-shot distribution pack:
- PUBLIC/: the thin trunk (shareable, normal, non-weird)
- PRIVATE/: the retained pack (proof, lineage, research, extended records)
- BOOT/: one-step entry scripts (Termux + Windows CMD)
- INTEGRITY/: deterministic manifest + verification scripts
- RECOVERY/: fail-closed rules + reversion forms
- INDEX/: canonical index placeholders + format specs
- QR/: normal black/white QR payload text blocks (you generate QR from these)

Zero implied memory. No hidden state. No silent mutation.
Continuity is explicit and carried by artifacts.

Quick start (Termux / Android):
  1) Unzip this package to storage or ~/ccs
  2) Open Termux
  3) cd into the folder
  4) run:  bash BOOT/termux_boot.sh

Quick start (Windows CMD):
  1) Extract ZIP
  2) Open Command Prompt in the folder
  3) run:  BOOT\windows_boot.cmd

What "loads state" means here:
- Verifies integrity (fail-closed)
- Assembles a runnable working directory
- Prints the exact next command(s) (and only those)
- No network required
- No cloud dependency

If you distribute this:
- Distribute the ZIP as-is
- Do not modify files inside (modification invalidates hashes)
