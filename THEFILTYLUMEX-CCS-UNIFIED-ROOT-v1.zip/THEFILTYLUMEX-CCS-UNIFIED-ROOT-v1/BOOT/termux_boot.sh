#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "[CCS] THEFILTYLUMEX CCS UNIFIED ROOT v1"
echo "[CCS] MODE: BOOT (stateless)"
echo ""

# Ensure tools
if ! command -v sha256sum >/dev/null 2>&1; then
  echo "[CCS] Installing required tools..."
  pkg update -y >/dev/null
  pkg install -y coreutils unzip >/dev/null
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "[CCS] Root: $ROOT_DIR"
echo "[CCS] Verifying integrity (fail-closed)..."
bash INTEGRITY/verify_termux.sh

echo ""
echo "[CCS] Integrity: OK"
echo "[CCS] Next actions:"
echo "  - PUBLIC files are in: PUBLIC/"
echo "  - PRIVATE files are in: PRIVATE/"
echo "  - Loader prompt: PUBLIC/CCS_LOADER_PROMPT.txt"
echo "  - To create new drops: use INTEGRITY/build_manifest_termux.sh after edits"
echo ""
