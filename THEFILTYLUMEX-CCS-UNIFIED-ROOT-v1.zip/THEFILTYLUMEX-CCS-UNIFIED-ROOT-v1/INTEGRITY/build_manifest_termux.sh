#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

OUT="INTEGRITY/MANIFEST_SHA256.txt"
TMP="INTEGRITY/.manifest_tmp.txt"

# Deterministic file list (exclude integrity temp files and the manifest itself until end)
find . -type f \
  ! -path "./INTEGRITY/.manifest_tmp.txt" \
  ! -path "./INTEGRITY/MANIFEST_SHA256.txt" \
  -print | LC_ALL=C sort > INTEGRITY/.files.txt

: > "$TMP"
while IFS= read -r f; do
  # remove leading ./
  rel="${f#./}"
  sha256sum "$rel" >> "$TMP"
done < INTEGRITY/.files.txt

# Now include the file list itself (optional) and then write out
mv "$TMP" "$OUT"

echo "[CCS] Wrote $OUT"
