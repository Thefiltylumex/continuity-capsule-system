#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MANIFEST="$ROOT_DIR/INTEGRITY/MANIFEST_SHA256.txt"

if [ ! -f "$MANIFEST" ]; then
  echo "[CCS] MISSING: INTEGRITY/MANIFEST_SHA256.txt"
  exit 10
fi

# Verify all lines: "<hash>  <relative_path>"
cd "$ROOT_DIR"
sha256sum -c "INTEGRITY/MANIFEST_SHA256.txt" >/dev/null

# Self-check: manifest line for itself must match
echo "[CCS] Verified: $(wc -l < INTEGRITY/MANIFEST_SHA256.txt) entries"
